import 'package:flutter/material.dart';

mixin AIColors {
  static Color? primaryColor1 = Colors.orange[400];
  static Color? primaryColor2 = Colors.purple[500];
}
